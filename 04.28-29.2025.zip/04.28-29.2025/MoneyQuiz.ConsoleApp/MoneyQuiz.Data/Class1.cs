﻿namespace MoneyQuiz.Data
{
    public class Class1
    {

    }
}
