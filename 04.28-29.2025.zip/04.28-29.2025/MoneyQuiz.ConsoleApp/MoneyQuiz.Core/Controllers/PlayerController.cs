﻿using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core.Controllers
{
    internal class PlayerController
    {

        public GameDbContext _context = new GameDbContext();

        public PlayerController(GameDbContext context)
        {
            _context = context;
        }

        public void AddPlayer()
        {
            Player player = new Player();
            _context.Players.Add(player);
            _context.SaveChanges();
        }


    }
}
