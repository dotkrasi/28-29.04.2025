﻿using MoneyQuiz.Core.Controllers;
using MoneyQuiz.Data;
using System;
using System.Collections.Generic;

namespace MoneyQuiz.ConsoleApp
{
    public class Display
    {
        private readonly QuestionController _questionController;
        private readonly PlayerController _playerController;
        private readonly AnswerController _answerController;
        private readonly LifeLinesController _lifeLinesController;

        public Display()
        {
            var context = new GameDbContext();
            _questionController = new QuestionController(context);
            _playerController = new PlayerController(context);
            _answerController = new AnswerController(context);
            _lifeLinesController = new LifeLinesController(context);
        }

        public void MainMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== МЕНЮ ===");
                Console.WriteLine("1. Добави въпрос");
                Console.WriteLine("2. Редактирай въпрос по ID");
                Console.WriteLine("3. Покажи въпроси със сума над 3000 лв.");
                Console.WriteLine("4. Покажи въпрос и верен отговор по сума");
                Console.WriteLine("5. Покажи всички въпроси");
                Console.WriteLine("6. Добави играч");
                Console.WriteLine("7. Добави отговори (4 накуп)");
                Console.WriteLine("8. Редактирай отговор по ID");
                Console.WriteLine("9. Изтрий жокери");
                Console.WriteLine("0. Изход");
                Console.Write("Избери опция: ");

                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": AddQuestion(); break;
                    case "2": EditQuestion(); break;
                    case "3": ShowQuestionsOver3000(); break;
                    case "4": ShowQuestionsWithCorrectAnswersByAmount(); break;
                    case "5": ShowAllQuestions(); break;
                    case "6": AddPlayer(); break;
                    case "7": AddAnswers(); break;
                    case "8": EditAnswer(); break;
                    case "9": RemoveLifeLines(); break;
                    case "0": return;
                    default: Console.WriteLine("Невалиден избор."); break;
                }

                Console.WriteLine("\nНатисни Enter за връщане в менюто...");
                Console.ReadLine();
            }
        }

        private void AddQuestion()
        {
            Console.Write("Въведи текст на въпроса: ");
            string text = Console.ReadLine();

            Console.Write("Въведи сума (Amount): ");
            decimal amount = decimal.Parse(Console.ReadLine());

            var answers = new List<Answer>();
            for (int i = 1; i <= 4; i++)
            {
                Console.Write($"Отговор {i}: ");
                string answerText = Console.ReadLine();

                Console.Write("Верен ли е този отговор (true/false): ");
                bool isCorrect = bool.Parse(Console.ReadLine());

                answers.Add(new Answer { AnswerText = answerText, IsCorrect = isCorrect });
            }

            var question = new Question
            {
                QuestionText = text,
                Amount = amount,
                Answers = answers
            };

            var context = new GameDbContext();
            context.Questions.Add(question);
            context.SaveChanges();

            Console.WriteLine("Въпросът е добавен успешно.");
        }

        private void EditQuestion()
        {
            Console.Write("Въведи ID на въпроса за редактиране: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Нов текст на въпроса: ");
            string newText = Console.ReadLine();

            Console.Write("Нова сума: ");
            decimal newAmount = decimal.Parse(Console.ReadLine());

            var newAnswers = new List<Answer>();
            for (int i = 1; i <= 4; i++)
            {
                Console.Write($"Нов отговор {i}: ");
                string answerText = Console.ReadLine();

                Console.Write("Верен ли е този отговор (true/false): ");
                bool isCorrect = bool.Parse(Console.ReadLine());

                newAnswers.Add(new Answer { AnswerText = answerText, IsCorrect = isCorrect });
            }

            _questionController.EditQuestion(id, newText, newAmount, newAnswers);
        }

        private void ShowQuestionsOver3000()
        {
            var questions = _questionController.GetQuestionsWithAmountOver3000();
            Console.WriteLine("Въпроси със сума над 3000 лв:");
            foreach (var q in questions)
                Console.WriteLine("- " + q);
        }

        private void ShowQuestionsWithCorrectAnswersByAmount()
        {
            Console.Write("Въведи сума: ");
            decimal amount = decimal.Parse(Console.ReadLine());

            var results = _questionController.GetQuestionsAndCorrectAnswersByAmount(amount);

            foreach (var (questionText, correctAnswer) in results)
            {
                Console.WriteLine($"Въпрос: {questionText}");
                Console.WriteLine($"Верен отговор: {correctAnswer}\n");
            }
        }

        private void ShowAllQuestions()
        {
            var questions = _questionController.ListAllQuestions();
            Console.WriteLine("Всички въпроси:");
            foreach (var q in questions)
                Console.WriteLine("- " + q);
        }

        private void AddPlayer()
        {
            _playerController.AddPlayer();
            Console.WriteLine("Играчът е добавен успешно.");
        }

        private void AddAnswers()
        {
            _answerController.AddAnswer();
            Console.WriteLine("4 отговора са добавени успешно.");
        }

        private void EditAnswer()
        {
            Console.Write("Въведи ID на отговора: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Нов текст на отговора: ");
            string newText = Console.ReadLine();

            Console.Write("Верен ли е този отговор (true/false): ");
            bool isCorrect = bool.Parse(Console.ReadLine());

            _answerController.EditAnswer(id, newText, isCorrect);
        }

        private void RemoveLifeLines()
        {
            _lifeLinesController.LifeLines();
            Console.WriteLine("Жокерите са премахнати.");
        }
    }
}
