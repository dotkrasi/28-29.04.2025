﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Data;

namespace MoneyQuiz.Core.Controllers
{
    public class QuestionController
    {
        public GameDbContext _context = new GameDbContext();

        public QuestionController(GameDbContext context)
        {
            _context = context;
        }

        public void AddQuestion()
        {
            Question question = new Question();
            _context.Questions.Add(question);
            _context.SaveChanges();
        }


        public void EditQuestion(int id, string newText, decimal newAmount, List<Answer> newAnswers)
        {
            var question = _context.Questions
                .Include(q => q.Answers)
                .FirstOrDefault(q => q.Id == id);

            if (question == null)
            {
                Console.WriteLine("Няма въпрос с такова ID.");
                return;
            }

            question.QuestionText = newText;
            question.Amount = newAmount;

            _context.Answers.RemoveRange(question.Answers);

            question.Answers = newAnswers;

            _context.SaveChanges();
            Console.WriteLine("Въпросът беше успешно редактиран.");

        }

        public List<string> GetQuestionsWithAmountOver3000()
        {
            return _context.Questions
                .Where(q => q.Amount > 3000)
                .Select(q => q.QuestionText)
                .ToList();
        }

        public List<string> ListAllQuestions()
        {
            return _context.Questions
                .Include(q => q.Answers)
                .Select(q => q.QuestionText)
                .ToList();
        }

        public List<(string QuestionText, string CorrectAnswer)> GetQuestionsAndCorrectAnswersByAmount(decimal amount)
        {
            return _context.Questions
                .Where(q => q.Amount == amount)
                .Select(q => new
                {
                    q.QuestionText,
                    CorrectAnswer = q.Answers.FirstOrDefault(a => a.IsCorrect)
                })
                .AsEnumerable() // тук минаваме към паметта (in-memory LINQ)
                .Where(x => x.CorrectAnswer != null)
                .Select(x => (x.QuestionText, x.CorrectAnswer.AnswerText))
                .ToList();
        }


    }
}
