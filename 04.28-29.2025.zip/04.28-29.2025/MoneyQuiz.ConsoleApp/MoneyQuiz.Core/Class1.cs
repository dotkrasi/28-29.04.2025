﻿namespace MoneyQuiz.Core
{
    public class Class1
    {

    }
}
