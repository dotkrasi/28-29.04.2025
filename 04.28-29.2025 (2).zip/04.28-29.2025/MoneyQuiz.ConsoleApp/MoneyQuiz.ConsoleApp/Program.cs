﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Core.Controllers;
using MoneyQuiz.Data;


namespace MoneyQuiz.ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            var display = new Display();
            display.MainMenu();
        }
    }
}
