﻿using Microsoft.EntityFrameworkCore;
using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core.Controllers
{
    public class LifeLinesController
    {
        public GameDbContext _context = new GameDbContext();

        public LifeLinesController(GameDbContext context)
        {
            _context = context;
        }

        public void LifeLines()
        {
            var lifelines = _context.Lifelines.FirstOrDefault(l => l.Id == 1);
            _context.Lifelines.Remove(lifelines);
            _context.SaveChanges();
        }
    }
}
