﻿using MoneyQuiz.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyQuiz.Core.Controllers
{
    public class AnswerController
    {
        public GameDbContext _context = new GameDbContext();

        public AnswerController(GameDbContext context)
        {
            _context = context;
        }


        public void AddAnswer()
        {
            Answer answer = new Answer();
            for (int i = 0; i < 4; i++)
            {
                _context.Answers.Add(answer);
            }
            _context.SaveChanges();
        }

        public void EditAnswer(int id, string newText, bool isCorrect)
        {
            var answer = _context.Answers.FirstOrDefault(a => a.Id == id);

            if (answer == null)
            {
                Console.WriteLine("Няма отговор с такова ID.");
                return;
            }

            answer.AnswerText = newText;
            answer.IsCorrect = isCorrect;

            _context.SaveChanges();
            Console.WriteLine("Отговорът беше успешно редактиран.");
        }
    }
}
