﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace MoneyQuiz.Data
{

    public class GameDbContext : DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<GameSession> GameSessions { get; set; }
        public DbSet<PlayerGameSession> PlayerGameSessions { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<PlayerAnswer> PlayerAnswers { get; set; }
        public DbSet<Lifeline> Lifelines { get; set; }

        public GameDbContext(DbContextOptions<GameDbContext> options)
            : base(options)
        {
        }

        public GameDbContext() { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Player
            modelBuilder.Entity<Player>(entity =>
            {
                entity.HasKey(p => p.Id);
                entity.Property(p => p.Name).IsRequired().HasMaxLength(100);
                entity.Property(p => p.Email).IsRequired().HasMaxLength(100);
            });

            // GameSession
            modelBuilder.Entity<GameSession>(entity =>
            {
                entity.HasKey(g => g.Id);
                entity.Property(g => g.Time).IsRequired();
                entity.Property(g => g.FinalAmount).HasColumnType("decimal(18,2)");
            });

            // PlayerGameSession
            modelBuilder.Entity<PlayerGameSession>(entity =>
            {
                entity.HasKey(pgs => pgs.Id);

                entity.HasOne(pgs => pgs.Player)
                    .WithMany(p => p.PlayerGameSessions)
                    .HasForeignKey(pgs => pgs.PlayerId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(pgs => pgs.GameSession)
                    .WithMany(gs => gs.PlayerGameSessions)
                    .HasForeignKey(pgs => pgs.SessionId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Question
            modelBuilder.Entity<Question>(entity =>
            {
                entity.HasKey(q => q.Id);
                entity.Property(q => q.QuestionText).IsRequired().HasMaxLength(500);
                entity.Property(q => q.Amount).HasColumnType("decimal(18,2)");
            });

            // Answer
            modelBuilder.Entity<Answer>(entity =>
            {
                entity.HasKey(a => a.Id);
                entity.Property(a => a.AnswerText).IsRequired().HasMaxLength(300);

                entity.HasOne(a => a.Question)
                    .WithMany(q => q.Answers)
                    .HasForeignKey(a => a.QuestionId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // PlayerAnswer
            modelBuilder.Entity<PlayerAnswer>(entity =>
            {
                entity.HasKey(pa => pa.Id);

                entity.HasOne(pa => pa.PlayerGameSession)
                    .WithMany(pgs => pgs.PlayerAnswers)
                    .HasForeignKey(pa => pa.PlayerSessionId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(pa => pa.Answer)
                    .WithMany(a => a.PlayerAnswers)
                    .HasForeignKey(pa => pa.AnswerId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Lifeline
            modelBuilder.Entity<Lifeline>(entity =>
            {
                entity.HasKey(l => l.Id);

                entity.Property(l => l.Type).IsRequired().HasMaxLength(100);

                entity.HasOne(l => l.PlayerGameSession)
                    .WithMany(pgs => pgs.Lifelines)
                    .HasForeignKey(l => l.PlayerGameSessionId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(l => l.UsedOnQuestion)
                    .WithMany()
                    .HasForeignKey(l => l.UsedOnQuestionId)
                    .OnDelete(DeleteBehavior.SetNull);
            });
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MoneyQuiz;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

        }
    }

}
